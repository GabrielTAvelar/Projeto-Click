import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyClxJDm_SkWj_VtyDTQ2Uw0m3IhHO74Iaw",
  authDomain: "projeto-clique-3971d.firebaseapp.com",
  databaseURL: "https://projeto-clique-3971d-default-rtdb.firebaseio.com",
  projectId: "projeto-clique-3971d",
  storageBucket: "projeto-clique-3971d.firebasestorage.app",
  messagingSenderId: "71809968741",
  appId: "1:71809968741:web:f4abd9eab00761d232b48c",
  measurementId: "G-YL2Y27LY74"
};


const app = initializeApp(firebaseConfig);