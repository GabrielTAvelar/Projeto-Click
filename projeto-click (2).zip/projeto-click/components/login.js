import React from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet } from 'react-native';
import firebase from '../config/config';

export default class LoginScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      usuario: '',
      senha: '',
    };
  }

  ler() {
    const email = (this.state.usuario || '').toLowerCase();
    const password = this.state.senha || '';

    firebase
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then(() => {
        Alert.alert('Logado!!!', 'Login realizado com sucesso!');
        //-----
      })
      .catch((error) => {
        if (error.code == 'auth/invalid-email') {
          Alert.alert('Erro', 'Formato do email inválido');
        } else {
          Alert.alert('Erro', 'Ocorreu um erro ao fazer login');
        }
      });
  }

  render() {
    return (
      <View style={estilos.container}>
        <Text style={estilos.texto}>Usuário para login:</Text>

        <TextInput
          style={estilos.input}
          autoCapitalize="none"
          onChangeText={(texto) => this.setState({ usuario: texto })}
        />

        <Text style={estilos.texto}>Senha:</Text>

        <TextInput
          style={estilos.input}
          secureTextEntry
          autoCapitalize="none"
          onChangeText={(texto) => this.setState({ senha: texto })}
        />

        <Button title="Logar" onPress={() => this.ler()} />
      </View>
    );
  }
}

const estilos = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20 },
  texto: { color: 'blue', fontSize: 25, alignSelf: 'center' },
  input: {
    height: 33,
    padding: 5,
    fontSize: 20,
    borderColor: 'black',
    borderWidth: 1,
    margin: 10,
    borderRadius: 8,
  },
});
