import React from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet } from 'react-native';
import firebase from '../config/config';

export default class CadastroScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      usuario: '',
      senha: '',
    };
  }

  cadastrar() {
    const email = this.state.usuario.toLowerCase();
    const password = this.state.senha;

    firebase
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then(() => {
        Alert.alert('Sucesso', 'Usuário cadastrado!');
        this.props.navigation.navigate('Login');
      })
      .catch((error) => {
        Alert.alert('Erro', 'Não foi possível realizar o cadastro.');
      });
  }

  render() {
    return (
      <View style={estilos.container}>
        <Text style={estilos.texto}>Email de Cadastro:</Text>

        <TextInput
          style={estilos.input}
          autoCapitalize="none"
          onChangeText={(texto) => this.setState({ usuario: texto })}
        />

        <Text style={estilos.texto}>Senha:</Text>

        <TextInput
          style={estilos.input}
          secureTextEntry
          onChangeText={(texto) => this.setState({ senha: texto })}
        />

        <Button title="Cadastrar" onPress={() => this.cadastrar()} />
      </View>
    );
  }
}

const estilos = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20 },
  texto: { color: 'blue', fontSize: 25, alignSelf: 'center' },
  input: {
    height: 33,
    padding: 5,
    fontSize: 20,
    borderColor: 'black',
    borderWidth: 1,
    margin: 10,
    borderRadius: 8,
  },
});
