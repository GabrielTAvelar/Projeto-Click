const ajustes = {
  vibracao: true
};

export default ajustes;