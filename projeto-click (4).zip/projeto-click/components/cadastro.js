import React from 'react';
import { View, Text, TextInput, Button, Alert, Platform } from 'react-native';

import firebase from '../config/config';

export default class Cadastro extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      usuario: '',
      senha: '',
    };
  }

  fazerCadastro() {
    const email = this.state.usuario.trim().toLowerCase();
    const senha = this.state.senha;

    const mensagem = (titulo, texto) => {
      if (Platform.OS === 'web') {
        alert(titulo + ': ' + texto);
      } else {
        Alert.alert(titulo, texto);
      }
    };

    if (!email || !senha) {
      mensagem('Atenção', 'Preencha todos os campos.');
      return;
    }

    if (senha.length < 6) {
      mensagem('Atenção', 'A senha precisa ter pelo menos 6 caracteres.');
      return;
    }

    firebase
      .auth()
      .createUserWithEmailAndPassword(email, senha)
      .then((resultado) => {
        console.log('Usuário cadastrado:', resultado.user.email);

        mensagem('Sucesso', 'Usuário cadastrado com sucesso!');

        this.props.navigation.navigate('Login');
      })
      .catch((erro) => {
        console.log('ERRO NO CADASTRO:', erro.message);

        mensagem('Erro no cadastro', erro.message);
      });
  }

  render() {
    return (
      <View style={{ flex: 1, justifyContent: 'center', padding: 25 }}>
        <Text style={{ fontSize: 25, marginBottom: 20 }}>Cadastro</Text>

        <TextInput
          placeholder="Email"
          keyboardType="email-address"
          autoCapitalize="none"
          value={this.state.usuario}
          onChangeText={(texto) => this.setState({ usuario: texto })}
          style={{ borderWidth: 1, padding: 10, marginBottom: 15 }}
        />

        <TextInput
          placeholder="Senha"
          secureTextEntry
          value={this.state.senha}
          onChangeText={(texto) => this.setState({ senha: texto })}
          style={{ borderWidth: 1, padding: 10, marginBottom: 15 }}
        />

        <Button title="Cadastrar" onPress={() => this.fazerCadastro()} />
      </View>
    );
  }
}
