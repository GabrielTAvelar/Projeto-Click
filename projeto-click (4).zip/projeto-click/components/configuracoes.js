import React from 'react';
import { View, Text, Switch, Button, StyleSheet } from 'react-native';

import ajustes from '../config/ajustes';

export default class Configuracoes extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      vibracao: ajustes.vibracao,
    };
  }

  alterarVibracao(valor) {
    ajustes.vibracao = valor;

    this.setState({
      vibracao: valor,
    });
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.titulo}>Configurações</Text>

        <View style={styles.linha}>
          <Text>Vibração ao clicar no sol</Text>

          <Switch
            value={this.state.vibracao}
            onValueChange={(valor) => this.alterarVibracao(valor)}
          />
        </View>

        <Button title="Voltar" onPress={() => this.props.navigation.goBack()} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 25,
    backgroundColor: '#FFFFFF',
  },

  titulo: {
    fontSize: 26,
    marginBottom: 30,
  },

  linha: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
});
