
import React from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet
} from 'react-native';

import { salvarPontuacao } from '../config/ranking';


export default class FimDeJogo extends React.Component {

  componentDidMount() {
  const pontos = this.props.route.params?.pontos ?? 0;

  salvarPontuacao(pontos)
    .then(() => {
      console.log('Pontuação salva com sucesso!');
    })
    .catch((erro) => {
      alert('Erro ao salvar: ' + erro.message);
    });
}

  render() {
    const pontos = this.props.route.params?.pontos ?? 0;

    return (
      <View style={styles.container}>
        <Text style={styles.titulo}>Fim de jogo!</Text>

        <Text style={styles.pontos}>
          Pontuação final: {pontos}
        </Text>

        <Button
          title="Voltar ao menu"
          onPress={() =>
            this.props.navigation.navigate('PaginaLogado')
          }
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E6E6E6'
  },

  titulo: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 30
  },

  pontos: {
    fontSize: 24,
    marginBottom: 30
  }
});
