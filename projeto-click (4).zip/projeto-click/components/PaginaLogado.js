import React from 'react';
import { Text, View, Button, StyleSheet, Alert } from 'react-native';
import firebase from '../config/config';

class PaginaLogado extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
    };
  }

  render() {
    return (
      <View>
        <Button
          title="Jogar"
          onPress={() => this.props.navigation.navigate('Jogo')}
        />

        <Button
          title="Rank"
          onPress={() => this.props.navigation.navigate('Rank')}
        />

        <Button
          title="Configurações"
          onPress={() => this.props.navigation.navigate('Configurações')}
        />
        <Button
          title="Sair"
          onPress={() => {
            firebase
              .auth()
              .signOut()
              .then(() => {
                this.props.navigation.replace('Acesso');
              })
              .catch((erro) => {
                Alert.alert('Erro ao sair', erro.message);
              });
          }}
        />

        <Text style={textos.container}>Acesso a plataforma</Text>

        <Text>{this.props.route.params?.email ?? ''}</Text>

        <Text>Seja bem-vindo!</Text>
      </View>
    );
  }
}

const textos = StyleSheet.create({
  container: {
    fontSize: 22,
    borderColor: 'gray',
    borderWidth: 1,
    textAlign: 'center',
  },
});

export default PaginaLogado;
