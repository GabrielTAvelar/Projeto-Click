import React from 'react';
import { Text, View, TouchableOpacity, StyleSheet, Alert } from 'react-native';

import firebase from '../config/config';

class PaginaLogado extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
    };
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.titulo}>Menu Principal</Text>

        <TouchableOpacity
          style={styles.botao}
          onPress={() => this.props.navigation.navigate('Jogo')}>
          <Text style={styles.textoBotao}>Jogar</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.botao}
          onPress={() => this.props.navigation.navigate('Rank')}>
          <Text style={styles.textoBotao}>Rank</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.botao}
          onPress={() => this.props.navigation.navigate('Configurações')}>
          <Text style={styles.textoBotao}>Configurações</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.botao}
          onPress={() => {
            firebase
              .auth()
              .signOut()
              .then(() => {
                this.props.navigation.replace('Acesso');
              })
              .catch((erro) => {
                Alert.alert('Erro ao sair', erro.message);
              });
          }}>
          <Text style={styles.textoBotao}>Sair</Text>
        </TouchableOpacity>

        <Text>{this.props.route.params?.email ?? ''}</Text>

        <Text>Seja bem-vindo!</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'gray',
    alignItems: 'center',
    justifyContent: 'center',
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 30,
  },

  botao: {
    backgroundColor: 'red',
    width: 180,
    height: 60,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },

  textoBotao: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000000',
  },
});

export default PaginaLogado;
