import React from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';

import firebase from '../config/config';

export default class Login extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      usuario: '',
      senha: '',
    };
  }

  fazerLogin() {
    const email = this.state.usuario.trim().toLowerCase();
    const senha = this.state.senha;

    if (!email || !senha) {
      Alert.alert('Atenção', 'Preencha todos os campos.');
      return;
    }

    firebase
      .auth()
      .signInWithEmailAndPassword(email, senha)
      .then((resultado) => {
        this.props.navigation.getParent().replace('PaginaLogado', {
          email: resultado.user.email,
        });
      })
      .catch((erro) => {
        console.log('ERRO NO LOGIN:', erro.message);
        alert('Erro no login: ' + erro.message);
      });
  }

  render() {
    return (
      <View style={{ flex: 1, justifyContent: 'center', padding: 30, backgroundColor: 'gray'}}>
        <Text style={{ fontSize: 25, marginBottom: 20 }}>Login</Text>

        <TextInput
          placeholder="Email"
          keyboardType="email-address"
          autoCapitalize="none"
          value={this.state.usuario}
          onChangeText={(texto) => this.setState({ usuario: texto })}
          style={{ borderWidth: 1, padding: 10, marginBottom: 15 }}
        />

        <TextInput
          placeholder="Senha"
          secureTextEntry
          value={this.state.senha}
          onChangeText={(texto) => this.setState({ senha: texto })}
          style={{ borderWidth: 1, padding: 10, marginBottom: 15 }}
        />

        <Button title="Entrar" onPress={() => this.fazerLogin()} />
      </View>
    );
  }
}
