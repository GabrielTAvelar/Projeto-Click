const firebaseConfig = {
  apiKey: 'AIzaSyClxJDm_SkWj_VtyDTQ2Uw0m3IhHO74Iaw',
  databaseURL: 'https://projeto-clique-3971d-default-rtdb.firebaseio.com',
};
let usuarioAtual = null;
let tokenAtual = null;
async function requisicao(tipo, email, senha) {
  const url = `https://identitytoolkit.googleapis.com/v1/accounts:${tipo}?key=${firebaseConfig.apiKey}`;
  const resposta = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: email,
      password: senha,
      returnSecureToken: true,
    }),
  });
  const dados = await resposta.json();
  if (!resposta.ok) {
    const erro = dados.error?.message || 'Erro desconhecido';
    throw new Error(erro);
  }
  usuarioAtual = { email: dados.email, uid: dados.localId };
  tokenAtual = dados.idToken;
  return { user: usuarioAtual };
}
const firebase = {
  auth() {
    return {
      createUserWithEmailAndPassword(email, senha) {
        return requisicao('signUp', email, senha);
      },
      signInWithEmailAndPassword(email, senha) {
        return requisicao('signInWithPassword', email, senha);
      },
      signOut() {
        usuarioAtual = null;
        tokenAtual = null;
        return Promise.resolve();
      },
      get currentUser() {
        return usuarioAtual;
      },
    };
  },
  getToken() {
    return tokenAtual;
  },
  databaseURL: firebaseConfig.databaseURL,
};
export default firebase;
