
import firebase from './config';

function criarURL(caminho) {
  const token = firebase.getToken();

  if (!token) {
    throw new Error('Faça login novamente.');
  }

  return `${firebase.databaseURL}/${caminho}.json?auth=${token}`;
}

export async function salvarPontuacao(pontos) {
  const usuario = firebase.auth().currentUser;

  if (!usuario) {
    throw new Error('Usuário não encontrado.');
  }

  const url = criarURL(`ranking/${usuario.uid}`);

  //--Consulta o recorde anterior
  const consulta = await fetch(url);

  if (!consulta.ok) {
    throw new Error('Não foi possível consultar o recorde.');
  }

  const anterior = await consulta.json();

  // --------Gurda a maior pontuacacao
  const recorde = Math.max(
    anterior?.pontos || 0,
    pontos
  );

  //------ Mantém o nome salvo no cadastro
  const nome = anterior?.nome ||
    'Jogador-' + usuario.uid.slice(0, 5);

  const resposta = await fetch(url, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      nome: nome,
      pontos: recorde
    })
  });

  if (!resposta.ok) {
    throw new Error('Não foi possível salvar a pontuação.');
  }
}

export async function listarRanking() {
  const resposta = await fetch(criarURL('ranking'));

  if (!resposta.ok) {
    throw new Error('Não foi possível carregar o ranking.');
  }

  const dados = await resposta.json();

  return Object.values(dados || {})
    .sort((a, b) => b.pontos - a.pontos)
    .slice(0, 10);
}
