import React from 'react';
import { View, Text, ScrollView } from 'react-native';

import { listarRanking } from '../config/ranking';

export default class Rank extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      jogadores: [],
      carregando: true,
      erro: '',
    };
  }

  componentDidMount() {
    listarRanking()
      .then((dados) => {
        this.setState({
          jogadores: dados,
          carregando: false,
        });
      })
      .catch((erro) => {
        this.setState({
          erro: erro.message,
          carregando: false,
        });
      });
  }

  render() {
    return (
      <ScrollView style={{ flex: 1, padding: 20 }}>
        <Text style={{ fontSize: 28, marginBottom: 20 }}>Ranking</Text>

        {this.state.carregando && <Text>Carregando...</Text>}

        {!!this.state.erro && <Text>{this.state.erro}</Text>}

        {!this.state.carregando &&
          !this.state.erro &&
          this.state.jogadores.length === 0 && (
            <Text>Nenhuma pontuação cadastrada.</Text>
          )}

        {this.state.jogadores.map((jogador, indice) => (
          <View
            key={indice}
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: 12,
              borderBottomWidth: 1,
            }}>
            <View style={{ flex: 1, marginRight: 10 }}>
              <Text
                allowFontScaling={false}
                style={{ fontSize: 16, flexShrink: 1 }}>
                {`${indice + 1}º - ${jogador.nome}   `}
              </Text>
            </View>

            <Text
              allowFontScaling={false}
              style={{ fontSize: 16, minWidth: 65, textAlign: 'right' }}>
              {`${jogador.pontos} pts   `}
            </Text>
          </View>
        ))}
      </ScrollView>
    );
  }
}
