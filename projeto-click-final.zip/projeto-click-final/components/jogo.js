import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Vibration,
  Platform,
  Image
} from 'react-native';

import ajustes from '../config/ajustes';

const TAMANHO_SOL = 143;

export default class Jogo extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      pontos: 0,
      tempo: 30,
      x: 0,
      y: 0,
      larguraArea: 0,
      alturaArea: 0,
    };
  }

  componentDidMount() {
    this.finalizou = false;

    this.intervalo = setInterval(() => {
      this.setState(
        (estadoAnterior) => ({
          tempo: Math.max(0, estadoAnterior.tempo - 1),
        }),
        () => {
          if (this.state.tempo === 0) {
            this.finalizarJogo();
          }
        }
      );
    }, 1000);
  }

  finalizarJogo() {
    if (this.finalizou) {
      return;
    }

    this.finalizou = true;

    clearInterval(this.intervalo);

    this.props.navigation.replace('FimDeJogo', {
      pontos: this.state.pontos,
    });
  }

  componentWillUnmount() {
    clearInterval(this.intervalo);
  }

  definirArea(evento) {
    const { width, height } = evento.nativeEvent.layout;

    this.setState(
      {
        larguraArea: width,
        alturaArea: height,
      },
      () => this.sortearPosicao()
    );
  }

  sortearPosicao() {
    const larguraMaxima = Math.max(0, this.state.larguraArea - TAMANHO_SOL);

    const alturaMaxima = Math.max(0, this.state.alturaArea - TAMANHO_SOL);

    const novoX = Math.random() * larguraMaxima;
    const novoY = Math.random() * alturaMaxima;

    this.setState({
      x: novoX,
      y: novoY,
    });
  }

  clicarSol() {
    if (ajustes.vibracao && Platform.OS !== 'web') {
      Vibration.vibrate(50);
    }

    this.setState(
      (estadoAnterior) => ({
        pontos: estadoAnterior.pontos + 1,
      }),
      () => this.sortearPosicao()
    );
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.hud}>
          <View style={styles.blocoHud}>
            <Text style={styles.textoHud}>Pontos:</Text>
            <Text style={styles.numeroHud}>{this.state.pontos}</Text>
          </View>

          <View style={styles.blocoHud}>
            <Text style={styles.textoHud}>Tempo:</Text>
            <Text style={styles.numeroHud}>{this.state.tempo}s</Text>
          </View>
        </View>
        <View
          style={styles.areaJogo}
          onLayout={(evento) => this.definirArea(evento)}>

<TouchableOpacity
  style={[
    styles.sol,
    {
      left: this.state.x,
      top: this.state.y,
    },
  ]}
  onPress={() => this.clicarSol()}
>

  <Image
    source={require('../assets/sol.png')}
    style={styles.imagemSol}
  />
</TouchableOpacity>



        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  hud: {
    minHeight: 90,
    backgroundColor: '#E6E6E6',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 12,
  },
  blocoHud: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  textoHud: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  numeroHud: {
    fontSize: 18,
    fontWeight: 'bold',
    minWidth: 45,
    paddingLeft: 5,
    paddingRight: 10,
  },

  areaJogo: {
    flex: 1,
    backgroundColor: 'White',
  },

  sol: {
    position: 'absolute',
    width: TAMANHO_SOL,
    height: TAMANHO_SOL,
    borderRadius: TAMANHO_SOL / 2,
    backgroundColor: '#FFD93D',
    alignItems: 'center',
    justifyContent: 'center',
  },
  imagemSol: {
  width: '100%',
  height: '100%',
  resizeMode: 'contain',
},

  textoSol: {
    fontSize: 45,
  },
});
