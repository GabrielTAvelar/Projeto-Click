import React from 'react';
import { View, Text, TextInput, Button, Alert, Platform } from 'react-native';

import firebase from '../config/config';

export default class Cadastro extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      nome: '',
      usuario: '',
      senha: '',
    };
  }

  fazerCadastro() {
    const nome = this.state.nome.trim();
    const email = this.state.usuario.trim().toLowerCase();
    const senha = this.state.senha;

    const mensagem = (titulo, texto) => {
      if (Platform.OS === 'web') {
        alert(titulo + ': ' + texto);
      } else {
        Alert.alert(titulo, texto);
      }
    };

    if (!nome || !email || !senha) {
      mensagem('Atenção', 'Preencha todos os campos.');
      return;
    }

    if (senha.length < 6) {
      mensagem('Atenção', 'A senha precisa ter pelo menos 6 caracteres.');
      return;
    }

    firebase
      .auth()
      .createUserWithEmailAndPassword(email, senha)
      .then(async (resultado) => {
        const uid = resultado.user.uid;

        try {
          const url = `${
            firebase.databaseURL
          }/ranking/${uid}.json?auth=${firebase.getToken()}`;

          const resposta = await fetch(url, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              nome: nome,
              pontos: 0,
            }),
          });

          if (!resposta.ok) {
            throw new Error('Não foi possível salvar o nome.');
          }

          mensagem('Sucesso', 'Usuário cadastrado com sucesso!');
        } catch (erro) {
          mensagem(
            'Atenção',
            'Conta criada, mas o nome não foi salvo: ' + erro.message
          );
        }

        this.props.navigation.navigate('Login');
      })
      .catch((erro) => {
        console.log('ERRO NO CADASTRO:', erro.message);
        mensagem('Erro no cadastro', erro.message);
      });
  }

  render() {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          padding: 25,
          backgroundColor: 'White',
        }}>
        <Text
          style={{
            fontSize: 25,
            marginBottom: 20,
          }}>
          Cadastro
        </Text>

        <TextInput
          placeholder="Nome do jogador"
          value={this.state.nome}
          onChangeText={(texto) => this.setState({ nome: texto })}
          style={{
            borderWidth: 1,
            padding: 10,
            marginBottom: 15,
          }}
        />

        <TextInput
          placeholder="Email"
          keyboardType="email-address"
          autoCapitalize="none"
          value={this.state.usuario}
          onChangeText={(texto) => this.setState({ usuario: texto })}
          style={{
            borderWidth: 1,
            padding: 10,
            marginBottom: 15,
          }}
        />

        <TextInput
          placeholder="Senha"
          secureTextEntry
          value={this.state.senha}
          onChangeText={(texto) => this.setState({ senha: texto })}
          style={{
            borderWidth: 1,
            padding: 10,
            marginBottom: 15,
          }}
        />

        <Button title="Cadastrar" onPress={() => this.fazerCadastro()} />
      </View>
    );
  }
}
