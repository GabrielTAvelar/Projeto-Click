import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

import { salvarPontuacao } from '../config/ranking';

export default class FimDeJogo extends React.Component {
  componentDidMount() {
    const pontos = this.props.route.params?.pontos ?? 0;

    salvarPontuacao(pontos)
      .then(() => {
        console.log('Pontuação salva com sucesso!');
      })
      .catch((erro) => {
        alert('Erro ao salvar: ' + erro.message);
      });
  }

  render() {
    const pontos = this.props.route.params?.pontos ?? 0;

    return (
      <View style={styles.container}>
        <Text style={styles.titulo} allowFontScaling={false}>
          Fim de jogo!
        </Text>

        <Text style={styles.pontos} allowFontScaling={false}>
          {`Pontuação final: ${pontos}   `}
        </Text>
        <TouchableOpacity
          style={styles.botao}
          onPress={() => this.props.navigation.navigate('PaginaLogado')}>
          <Text style={styles.textoBotao} allowFontScaling={false}>
            Voltar ao menu
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#E6E6E6',
  },

  titulo: {
    width: '100%',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    paddingHorizontal: 20,
    paddingVertical: 10,
    marginBottom: 25,
  },

  pontos: {
    fontSize: 20,
    textAlign: 'center',
    paddingHorizontal: 20,
    marginBottom: 30,
  },

  botao: {
    backgroundColor: '#FFD93D',
    width: '85%',
    maxWidth: 280,
    minHeight: 60,
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  textoBotao: {
    width: '100%',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#000000',
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
});
