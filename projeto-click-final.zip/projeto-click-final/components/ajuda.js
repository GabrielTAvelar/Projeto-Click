import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default class Ajuda extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.titulo}>Como jogar:</Text>
        <Text style={styles.linha}>
          O objetivo do jogo é simples, o usuário tem 30 segundos para clicar o máximo de vezes possível no sol. Toda hora que o sol é clicado, ele muda de posição. Quem tiver a maior pontuação vence.
          Para ver a pontuação, é necessário ir ao menu e clicar no botão RANK. Também é possível ver a pontuação no fim de cada partida.
        </Text>

        <Button 
          title="Voltar" 
          onPress={() => this.props.navigation.goBack()} 
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 25,
    backgroundColor: '#FFFFFF',
  },

  titulo: {
    fontSize: 26,
    marginBottom: 30,
  },

  linha: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
});
