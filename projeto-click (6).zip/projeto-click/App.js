import 'react-native-gesture-handler';

import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';

import Login from './components/login';
import Cadastro from './components/cadastro';
import PaginaLogado from './components/PaginaLogado';
import Jogo from './components/jogo';
import FimDeJogo from './components/fimDeJogo';
import Rank from './components/rank';
import Configuracoes from './components/configuracoes';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function NavTab() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Login" component={Login} />
      <Tab.Screen name="Cadastro" component={Cadastro} />
    </Tab.Navigator>
  );
}


export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Acesso">
        <Stack.Screen
          name="Acesso"
          component={NavTab}
          options={{ headerShown: false }}
        />

        <Stack.Screen
          name="PaginaLogado"
          component={PaginaLogado}
          options={{ headerShown: false }}
        />

        <Stack.Screen
          name="Jogo"
          component={Jogo}
          options={{ headerShown: false }}
        />

        <Stack.Screen 
        name="Rank" 
        component={Rank} 
        />

        <Stack.Screen
          name="Configurações"
          component={Configuracoes}
        />

        <Stack.Screen
          name="FimDeJogo"
          component={FimDeJogo}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
